package lab01;

/**
 * An example class that doesn't do much
 */
public class HelloWorld {
    /**
     * A simple main method that prints "Hello, World!" to the
     * console
     */
    public static void main(String[] args) {
        System.out.println("Hello, World!");
    }
}